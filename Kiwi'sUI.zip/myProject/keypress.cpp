#include "keypress.h"
#include <QApplication>
#include <QKeyEvent>
#include "control.h"
#include "res.h"

bool flag;

KeyPress::KeyPress(QWidget *parent) :
    QWidget(parent)
{
     up      = new QLabel("Up");
     down    = new QLabel("Down");
     left    = new QLabel("Left");
     right   = new QLabel("Right");
     fire    = new QLabel("Fire");
     bomb    = new QLabel("Bomb");

    mainLayout = new QVBoxLayout;

    setGeometry(300,300,600,600);

    mainLayout->addWidget(up);
    mainLayout->addWidget(down);
    mainLayout->addWidget(left);
    mainLayout->addWidget(right);
    mainLayout->addWidget(fire);
    mainLayout->addWidget(bomb);

    setLayout(mainLayout);

}

void KeyPress::keyPressEvent(QKeyEvent *event)
{

    if((event->key() == Qt::Key_W)&&!(event->isAutoRepeat()))
    {
        flag = 0;
        up->setText("You pressed Up");
        if( !flag )
        {
        control.UpPressed = 1;
        }
        flag = 1;
    }

    if(event->key() == Qt::Key_S)
    {
        down->setText("You pressed Down");
        if(control.DownPressed = 0)
        control.DownPressed = 1;
    }

    if(event->key() == Qt::Key_A)
    {
        left->setText("You pressed Left");
        if(control.LeftPressed = 0)
        control.LeftPressed = 1;
    }

    if(event->key() == Qt::Key_D)
    {
        right->setText("You pressed Right");
        if(control.RightPressed = 0)
        control.RightPressed = 1;
    }

    if(event->key() == Qt::Key_Comma)
    {
        fire->setText("You pressed Fire");
        if(control.FirePressed = 0)
        control.FirePressed = 1;

    }

    if(event->key() == Qt::Key_Period)
    {
        bomb->setText("You pressed Bomb");
        if(control.BombClicked = 0)
        control.BombClicked = 1;
    }
}

void KeyPress::keyReleaseEvent(QKeyEvent *event)
{

    if((event->key() == Qt::Key_W)&&!(event->isAutoRepeat())&&(control.UpPressed = 1))
    {
        up->setText("You realeased Up");
        if( flag )
        {
        control.UpPressed = 0;
        }
        flag = 0;

    }

    if(event->key() == Qt::Key_S)
    {
        down->setText("You realeased Down");
        if(control.DownPressed == 1 )
         {
            control.DownPressed = 0;
         }
    }

    if(event->key() == Qt::Key_A)
    {
        left->setText("You released Left");
        if(control.LeftPressed == 1 )
         {
            control.LeftPressed = 0;
         }
    }

    if(event->key() == Qt::Key_D)
    {
        right->setText("You released Right");
        if(control.RightPressed == 1 )
         {
            control.RightPressed = 0;
         }
    }

    if(event->key() == Qt::Key_Comma)
    {
        fire->setText("You released Fire");
        if(control.FirePressed == 1 )
         {
            control.FirePressed = 0;
         }
    }

    if(event->key() == Qt::Key_Period)
    {
        bomb->setText("You released Bomb");
        if(control.BombClicked == 1 )
         {
            control.BombClicked = 0;
         }
    }

}


