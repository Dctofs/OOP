#ifndef RES_H
#define RES_H

#include "control.h"
#include "gamepara.h"

extern Control control;
extern GamePara gamepara;

#endif // RES_H

