#include "mainwindow.h"
#include <QApplication>
#include "res.h"
#include "control.h"

Control control;
GamePara gamepara;

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    MainWindow mainWin;
    mainWin.show();

    return app.exec();
}
