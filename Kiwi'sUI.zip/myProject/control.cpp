#include "control.h"

Control::Control()
{
    LeftPressed = 0;
    RightPressed = 0;
    UpPressed = 0;
    DownPressed = 0;
    FirePressed = 0;
    BombClicked = 0;
    PauseClicked = 0;
}
