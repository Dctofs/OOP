/********************************************************************************
** Form generated from reading UI file 'valueshow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VALUESHOW_H
#define UI_VALUESHOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_valueshow
{
public:
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_2;
    QLabel *label_2;
    QLabel *label_12;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_11;
    QLabel *label_3;
    QLabel *label_8;
    QLabel *label_6;
    QLineEdit *lineEdit_5;
    QLabel *label_7;
    QLabel *label_16;
    QLineEdit *lineEdit_4;
    QLabel *label_15;
    QLabel *label_5;
    QLineEdit *lineEdit_10;
    QLabel *label_9;
    QLineEdit *lineEdit_14;
    QLabel *label_13;
    QLineEdit *lineEdit_13;
    QLabel *label;
    QLabel *label_4;
    QLineEdit *lineEdit_12;
    QLabel *label_11;
    QLabel *label_10;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_15;

    void setupUi(QDialog *valueshow)
    {
        if (valueshow->objectName().isEmpty())
            valueshow->setObjectName(QStringLiteral("valueshow"));
        valueshow->resize(718, 706);
        lineEdit_6 = new QLineEdit(valueshow);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(130, 230, 81, 31));
        lineEdit_6->setAlignment(Qt::AlignCenter);
        lineEdit_3 = new QLineEdit(valueshow);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(180, 110, 71, 31));
        lineEdit_3->setAlignment(Qt::AlignCenter);
        lineEdit_8 = new QLineEdit(valueshow);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(130, 270, 81, 31));
        lineEdit_8->setAlignment(Qt::AlignCenter);
        lineEdit_2 = new QLineEdit(valueshow);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(250, 70, 81, 31));
        lineEdit_2->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(valueshow);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 70, 191, 24));
        label_12 = new QLabel(valueshow);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(50, 390, 108, 24));
        lineEdit_9 = new QLineEdit(valueshow);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(130, 350, 61, 31));
        lineEdit_9->setAlignment(Qt::AlignCenter);
        lineEdit_11 = new QLineEdit(valueshow);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(130, 390, 61, 31));
        lineEdit_11->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(valueshow);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 110, 108, 24));
        label_8 = new QLabel(valueshow);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(50, 310, 121, 24));
        label_6 = new QLabel(valueshow);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(50, 230, 108, 24));
        lineEdit_5 = new QLineEdit(valueshow);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(130, 190, 81, 31));
        lineEdit_5->setAlignment(Qt::AlignCenter);
        label_7 = new QLabel(valueshow);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(50, 270, 108, 24));
        label_16 = new QLabel(valueshow);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(50, 590, 141, 24));
        lineEdit_4 = new QLineEdit(valueshow);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(260, 150, 131, 31));
        lineEdit_4->setAlignment(Qt::AlignCenter);
        label_15 = new QLabel(valueshow);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(50, 550, 141, 24));
        label_5 = new QLabel(valueshow);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(50, 190, 108, 24));
        lineEdit_10 = new QLineEdit(valueshow);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(190, 510, 150, 31));
        lineEdit_10->setAlignment(Qt::AlignCenter);
        label_9 = new QLabel(valueshow);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(50, 350, 108, 24));
        lineEdit_14 = new QLineEdit(valueshow);
        lineEdit_14->setObjectName(QStringLiteral("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(190, 550, 113, 31));
        lineEdit_14->setAlignment(Qt::AlignCenter);
        label_13 = new QLabel(valueshow);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(50, 510, 131, 24));
        lineEdit_13 = new QLineEdit(valueshow);
        lineEdit_13->setObjectName(QStringLiteral("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(130, 430, 51, 31));
        lineEdit_13->setAlignment(Qt::AlignCenter);
        label = new QLabel(valueshow);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 30, 131, 24));
        label_4 = new QLabel(valueshow);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(50, 150, 181, 31));
        lineEdit_12 = new QLineEdit(valueshow);
        lineEdit_12->setObjectName(QStringLiteral("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(130, 470, 51, 31));
        lineEdit_12->setAlignment(Qt::AlignCenter);
        label_11 = new QLabel(valueshow);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(50, 470, 108, 24));
        label_10 = new QLabel(valueshow);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(50, 430, 108, 24));
        lineEdit = new QLineEdit(valueshow);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(190, 30, 220, 31));
        lineEdit->setAlignment(Qt::AlignCenter);
        lineEdit_7 = new QLineEdit(valueshow);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(190, 310, 170, 31));
        lineEdit_7->setAlignment(Qt::AlignCenter);
        lineEdit_15 = new QLineEdit(valueshow);
        lineEdit_15->setObjectName(QStringLiteral("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(190, 590, 140, 31));
        lineEdit_15->setAlignment(Qt::AlignCenter);

        retranslateUi(valueshow);

        QMetaObject::connectSlotsByName(valueshow);
    } // setupUi

    void retranslateUi(QDialog *valueshow)
    {
        valueshow->setWindowTitle(QApplication::translate("valueshow", "valueshow", 0));
        label_2->setText(QApplication::translate("valueshow", "backGroundSound", 0));
        label_12->setText(QApplication::translate("valueshow", "Down", 0));
        label_3->setText(QApplication::translate("valueshow", "bombSound", 0));
        label_8->setText(QApplication::translate("valueshow", "LasterFire", 0));
        label_6->setText(QApplication::translate("valueshow", "Bomb", 0));
        label_7->setText(QApplication::translate("valueshow", "Start", 0));
        label_16->setText(QApplication::translate("valueshow", "InitialBomb", 0));
        label_15->setText(QApplication::translate("valueshow", "Reborntime", 0));
        label_5->setText(QApplication::translate("valueshow", "Fire", 0));
        label_9->setText(QApplication::translate("valueshow", "Up", 0));
        label_13->setText(QApplication::translate("valueshow", "Difficulty", 0));
        label->setText(QApplication::translate("valueshow", "ScreenMode", 0));
        label_4->setText(QApplication::translate("valueshow", "KeybordOrJoypad", 0));
        label_11->setText(QApplication::translate("valueshow", "Right", 0));
        label_10->setText(QApplication::translate("valueshow", "Left", 0));
        lineEdit->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class valueshow: public Ui_valueshow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VALUESHOW_H
