#include "operation.h"
#include "ui_operation.h"
#include "iostream"
#include "res.h"



using namespace std;

Operation::Operation(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Operation)
{
    ui->setupUi(this);
}

Operation::~Operation()
{
    delete ui;
}

void Operation::on_pushButton_8_clicked()
{
    QString Qstr =ui->comboBox->currentText();
    string str = Qstr.toLatin1();
    cout<<"Operator "<<str<<endl;


    if(str.compare("Keyboard") == 0)
        gamepara.KeybordOrJoypad = 0;
    else
        gamepara.KeybordOrJoypad = 1;

    int a = ui->checkBox_3->isChecked();
    gamepara.LasterFire = a;

    Qstr=ui->lineEdit_8->text();
    str = Qstr.toLatin1();
    cout<<"Fire "<<str<<endl;
    char c = str.at(0);
    gamepara.fire = int(c);

    Qstr=ui->lineEdit_9->text();
    str = Qstr.toLatin1();
    cout<<"Bomb "<<str<<endl;
    c = str.at(0);
    gamepara.bomb = int(c);

    Qstr=ui->lineEdit_10->text();
    str = Qstr.toLatin1();
    cout<<"Start "<<str<<endl;
    if(str.compare("Enter")==0)
    gamepara.start = 32;
    else
    {
        c = str.at(0);
        gamepara.start = int (c);
    }

    Qstr=ui->lineEdit_4->text();
    str = Qstr.toLatin1();
    cout<<"Up "<<str<<endl;
    c = str.at(0);
    gamepara.up = int(c);

    Qstr=ui->lineEdit_11->text();
    str = Qstr.toLatin1();
    cout<<"Down "<<str<<endl;
    c = str.at(0);
    gamepara.down = int(c);

    Qstr=ui->lineEdit_13->text();
    str = Qstr.toLatin1();
    cout<<"Left "<<str<<endl;
    c = str.at(0);
    gamepara.left = int(c);

    Qstr=ui->lineEdit_12->text();
    str = Qstr.toLatin1();
    cout<<"Right "<<str<<endl;
    c = str.at(0);
    gamepara.right = int(c);

    this->close();
}


void Operation::on_pushButton_9_clicked()
{
    this->close();
}


void Operation::on_pushButton_3_clicked()
{
    ui->lineEdit_8->setText(",");
    ui->lineEdit_9->setText(".");
    ui->lineEdit_10->setText("Space");
    ui->checkBox_3->setChecked(1);
    ui->lineEdit_4->setText("W");
    ui->lineEdit_11->setText("S");
    ui->lineEdit_13->setText("A");
    ui->lineEdit_12->setText("D");
}
